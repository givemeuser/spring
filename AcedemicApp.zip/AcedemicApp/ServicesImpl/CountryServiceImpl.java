package com.AcedemicApp.AcedemicApp.ServicesImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.AcedemicApp.AcedemicApp.Entity.Country;
import com.AcedemicApp.AcedemicApp.Repository.CountryRepository;
import com.AcedemicApp.AcedemicApp.Services.CountryService;
@Service
public class CountryServiceImpl implements CountryService {
	@Autowired
	private CountryRepository countryRepository;

	public CountryServiceImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public List<Country> getCountries() {
		// TODO Auto-generated method stub
		return countryRepository.findAll();
	}

	@Override
	public Optional<Country> getCountry(Long countryId) {
		// TODO Auto-generated method stub
		return countryRepository.findById(countryId);
	}

	@Override
	public Country addCountry(Country country) {
		// TODO Auto-generated method stub
		countryRepository.save(country);
		return country;
	}

	@Override
	public Country updateCountry(Country country) {
		// TODO Auto-generated method stub
		countryRepository.save(country);
		return country;
	}

	@SuppressWarnings("deprecation")
	@Override
	public void deleteCountry(Long countryId) {
		// TODO Auto-generated method stub
		countryRepository.getById(countryId);
		Country country = countryRepository.getOne(countryId);
		countryRepository.delete(country);
	}
}
