package com.AcedemicApp.AcedemicApp.ServicesImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.AcedemicApp.AcedemicApp.Entity.City;
import com.AcedemicApp.AcedemicApp.Repository.CityRepository;
import com.AcedemicApp.AcedemicApp.Services.CityService;
@Service
public class CityServiceImpl implements CityService {
	@Autowired
	private CityRepository cityRepository;

	public CityServiceImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public List<City> getCities() {
		// TODO Auto-generated method stub
		return cityRepository.findAll();
	}

	@Override
	public Optional<City> getCity(Long cityId) {
		// TODO Auto-generated method stub
		return cityRepository.findById(cityId);
	}

	@Override
	public City addCity(City city) {
		// TODO Auto-generated method stub
		cityRepository.save(city);
		return city;
	}

	@Override
	public City updateCity(City city) {
		// TODO Auto-generated method stub
		cityRepository.save(city);
		return city;
	}

	@SuppressWarnings("deprecation")
	@Override
	public void deleteCity(Long cityId) {
		// TODO Auto-generated method stub
		cityRepository.getById(cityId);
		City city = cityRepository.getOne(cityId);
		cityRepository.delete(city);
	}
}
