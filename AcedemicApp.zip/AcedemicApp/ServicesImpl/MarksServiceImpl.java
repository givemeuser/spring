package com.AcedemicApp.AcedemicApp.ServicesImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.AcedemicApp.AcedemicApp.Entity.Marks;
import com.AcedemicApp.AcedemicApp.Repository.MarksRepository;
import com.AcedemicApp.AcedemicApp.Services.MarksService;
@Service
public class MarksServiceImpl implements MarksService {
	@Autowired
	private MarksRepository marksRepository;

	@Override
	public List<Marks> getAllMarks() {
		// TODO Auto-generated method stub
		return marksRepository.findAll();
	}

	@Override
	public Optional<Marks> getMarks(Long marksId) {
		// TODO Auto-generated method stub
		return marksRepository.findById(marksId);
	}

	@Override
	public Marks addMarks(Marks marks) {
		// TODO Auto-generated method stub
		marksRepository.save(marks);
		return marks;
	}

	@Override
	public Marks updateMarks(Marks marks) {
		// TODO Auto-generated method stub
		marksRepository.save(marks);
		return marks;
	}

	@SuppressWarnings("deprecation")
	@Override
	public void deleteMarks(Long marksId) {
		// TODO Auto-generated method stub
		marksRepository.getById(marksId);
		Marks marks = marksRepository.getOne(marksId);
		marksRepository.delete(marks);
	}
}
