package com.AcedemicApp.AcedemicApp.ServicesImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.AcedemicApp.AcedemicApp.Entity.Degree;
import com.AcedemicApp.AcedemicApp.Repository.DegreeRepository;
import com.AcedemicApp.AcedemicApp.Services.DegreeService;
@Service
public class DegreeServiceImpl implements DegreeService {
	@Autowired
	private DegreeRepository degreeRepository;

	@Override
	public List<Degree> getAllDegree() {
		// TODO Auto-generated method stub
		return degreeRepository.findAll();
	}

	@Override
	public Optional<Degree> getDegree(Long degreeId) {
		// TODO Auto-generated method stub
		return degreeRepository.findById(degreeId);
	}

	@Override
	public Degree addDegree(Degree degree) {
		// TODO Auto-generated method stub
		degreeRepository.save(degree);
		return degree;
	}

	@Override
	public Degree updateDegree(Degree degree) {
		// TODO Auto-generated method stub
		degreeRepository.save(degree);
		return degree;
	}

	@SuppressWarnings("deprecation")
	@Override
	public void deleteDegree(Long degreeId) {
		// TODO Auto-generated method stub
		degreeRepository.getById(degreeId);
		Degree degree = degreeRepository.getOne(degreeId);
		degreeRepository.delete(degree);
	}
}
