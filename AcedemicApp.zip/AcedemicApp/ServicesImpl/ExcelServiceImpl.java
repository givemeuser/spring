package com.AcedemicApp.AcedemicApp.ServicesImpl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.AcedemicApp.AcedemicApp.Entity.Student;
import com.AcedemicApp.AcedemicApp.Repository.ExcelReposiory;
import com.AcedemicApp.AcedemicApp.Repository.StudentRepository;
import com.AcedemicApp.AcedemicApp.Services.ExcelService;

@Service
public class ExcelServiceImpl implements ExcelService{
	@Autowired
	private ExcelReposiory excelReposiory;
	
	@Autowired
	private StudentRepository studentRepository;
	
	@Override
	public void generatedXls(HttpServletResponse response) throws IOException{
		List<Student> students = excelReposiory.findAll();
		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet createSheet = workbook.createSheet("Employee Details");
		XSSFRow createRow = createSheet.createRow(0);
		createRow.createCell(0).setCellValue("Name");
		createRow.createCell(1).setCellValue("Roll_No");
		int dataRowIndex = 1;
		for(Student st : students) {
		XSSFRow dataRow = createSheet.createRow(dataRowIndex);
		dataRow.createCell(0).setCellValue(st.getName());
		dataRow.createCell(1).setCellValue(st.getRollNo());
		dataRowIndex++;
		}
		ServletOutputStream outputStream = response.getOutputStream();
		workbook.write(outputStream);
		workbook.close();
		outputStream.close();

	}
	
	@Override
	public void generatedRep(HttpServletResponse response,Long StudentId) throws IOException{
		Student students = excelReposiory.findById(StudentId).get();
		List<List<Object>> report = studentRepository.getReport(StudentId);
		
		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet createSheet = workbook.createSheet("Employee Details");
		XSSFRow createRow = createSheet.createRow(0);
		createRow.createCell(0).setCellValue("Name");
		createRow.createCell(1).setCellValue("Roll_No");
		int dataRowIndex = 1;
		
		XSSFRow dataRow = createSheet.createRow(dataRowIndex);
		dataRow.createCell(0).setCellValue(students.getName());
		dataRow.createCell(1).setCellValue(students.getRollNo());
		dataRowIndex++;
		dataRowIndex = 4;
		dataRow = createSheet.createRow(dataRowIndex);
		dataRow.createCell(1).setCellValue("Subject Name");
		dataRow.createCell(2).setCellValue("Obtained Marks");
		dataRow.createCell(3).setCellValue("Passing Marks");
		dataRow.createCell(4).setCellValue("Total Marks");
		dataRowIndex++;
		/*
		for(List innerList : report) {
			for(Object obj : innerList) {
				for(int i=0;i<innerList.size();i++) {
				dataRow.createCell(i).setCellValue(obj.toString());
				}
			}
			dataRowIndex++;
		}
		*/
		
		for(int i=0;i<report.size();i++) {
			List<Object> innerList = report.get(i);
			dataRow = createSheet.createRow(dataRowIndex);
			for(int j =0;j<innerList.size();j++) {
				System.out.println(innerList.get(j).toString()+" ");
				dataRow.createCell(j+1).setCellValue(innerList.get(j).toString());
			}
			dataRowIndex++;
		}
		
		ServletOutputStream outputStream = response.getOutputStream();
		workbook.write(outputStream);
		workbook.close();
		outputStream.close();

	}
	
}
