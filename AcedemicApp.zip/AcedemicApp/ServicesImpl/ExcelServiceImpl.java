package com.AcedemicApp.AcedemicApp.ServicesImpl;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.AcedemicApp.AcedemicApp.Entity.Student;
import com.AcedemicApp.AcedemicApp.Repository.ExcelReposiory;
import com.AcedemicApp.AcedemicApp.Services.ExcelService;

@Service
public class ExcelServiceImpl implements ExcelService{
	@Autowired
	private ExcelReposiory excelReposiory;
	@Override
	public void generatedXls(HttpServletResponse response) throws IOException{
		List<Student> students = excelReposiory.findAll();
		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet createSheet = workbook.createSheet("Employee Details");
		XSSFRow createRow = createSheet.createRow(0);
		createRow.createCell(0).setCellValue("Name");
		createRow.createCell(1).setCellValue("Roll_No");
		int dataRowIndex = 1;
		for(Student st : students) {
		XSSFRow dataRow = createSheet.createRow(dataRowIndex);
		dataRow.createCell(0).setCellValue(st.getName());
		dataRow.createCell(1).setCellValue(st.getRollNo());
		dataRowIndex++;
		}
		ServletOutputStream outputStream = response.getOutputStream();
		workbook.write(outputStream);
		workbook.close();
		outputStream.close();

	}
}
