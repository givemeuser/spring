package com.AcedemicApp.AcedemicApp.ServicesImpl;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.AreaReference;
import org.apache.poi.ss.util.CellReference;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFTable;
import org.apache.poi.xssf.usermodel.XSSFTableStyleInfo;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.AcedemicApp.AcedemicApp.Documentation.ReportCard;
import com.AcedemicApp.AcedemicApp.Entity.Student;
import com.AcedemicApp.AcedemicApp.Repository.ExcelReposiory;
import com.AcedemicApp.AcedemicApp.Repository.StudentRepository;
import com.AcedemicApp.AcedemicApp.Services.ExcelService;

@Service
public class ExcelServiceImpl implements ExcelService{
	@Autowired
	private ExcelReposiory excelReposiory;
	
	@Autowired
	private StudentRepository studentRepository;
	
	@Override
	public void generatedXls(HttpServletResponse response) throws IOException{
		List<Student> students = excelReposiory.findAll();
		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet createSheet = workbook.createSheet("Student Details");
		XSSFRow createRow = createSheet.createRow(0);
		createRow.createCell(0).setCellValue("Name");
		createRow.createCell(1).setCellValue("Roll_No");
		int dataRowIndex = 1;
		for(Student st : students) {
		XSSFRow dataRow = createSheet.createRow(dataRowIndex);
		dataRow.createCell(0).setCellValue(st.getName());
		dataRow.createCell(1).setCellValue(st.getRollNo());
		dataRowIndex++;
		}
		ServletOutputStream outputStream = response.getOutputStream();
		workbook.write(outputStream);
		workbook.close();
		outputStream.close();

	}
	
	@Override
	public void generatedRep(HttpServletResponse response,Long StudentId) throws IOException{
		Student students = excelReposiory.findById(StudentId).get();
		
		List<List<Object>> report = studentRepository.getReport(StudentId);
		
		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet createSheet = workbook.createSheet("Student Details");
		XSSFRow createRow = createSheet.createRow(0);
		XSSFCellStyle style = workbook.createCellStyle();
		style.setBorderTop(BorderStyle.MEDIUM);
		style.setBorderBottom(BorderStyle.MEDIUM);
		style.setBorderLeft(BorderStyle.MEDIUM);
		style.setBorderRight(BorderStyle.MEDIUM);
		createRow.createCell(2).setCellValue("Name");
		createRow.createCell(4).setCellValue(students.getName());
		int dataRowIndex = 1;
		
		XSSFRow dataRow = createSheet.createRow(dataRowIndex);
		dataRow.createCell(2).setCellValue("Roll_No");
		dataRow.createCell(4).setCellValue(students.getRollNo());
		dataRowIndex++;
		dataRow = createSheet.createRow(dataRowIndex);
		dataRow.createCell(2).setCellValue("University Name");
		dataRow.createCell(4).setCellValue(studentRepository.getUniversityName(StudentId));

		dataRowIndex++;
		dataRowIndex = 4;
		dataRow = createSheet.createRow(dataRowIndex);
		dataRow.createCell(2).setCellValue("Subject Name");
		dataRow.createCell(3).setCellValue("Obtained Marks");
		dataRow.createCell(4).setCellValue("Passing Marks");
		dataRow.createCell(5).setCellValue("Total Marks");
		dataRowIndex++;
		/*
		for(List innerList : report) {
			for(Object obj : innerList) {
				for(int i=0;i<innerList.size();i++) {
				dataRow.createCell(i).setCellValue(obj.toString());
				}
			}
			dataRowIndex++;
		}
		*/
		
		for(int i=0;i<report.size();i++) {
			List<Object> innerList = report.get(i);
			dataRow = createSheet.createRow(dataRowIndex);
			for(int j =0;j<innerList.size();j++) {
				System.out.println(innerList.get(j).toString()+" ");
				dataRow.createCell(j+2).setCellValue(innerList.get(j).toString());
			}
			dataRowIndex++;
		}
		dataRow = createSheet.createRow(dataRowIndex);
		dataRow.createCell(2).setCellValue("Total");
		dataRow.createCell(3).setCellValue(studentRepository.getTotalMarks(StudentId));
		dataRow.createCell(5).setCellValue(studentRepository.getOutOfMarks(StudentId));
		dataRowIndex++;
		dataRow = createSheet.createRow(dataRowIndex);
		dataRow.createCell(2).setCellValue("Percent");
		dataRow.createCell(3).setCellFormula("D12/F12*100");
		ServletOutputStream outputStream = response.getOutputStream();
		workbook.write(outputStream);
		workbook.close();
		outputStream.close();

	}

	@Override
	public void generateDTOxlsx(HttpServletResponse response, Long StudentId) throws IOException {
		// TODO Auto-generated method stub
		List<ReportCard> reportCards = studentRepository.getReportCard(StudentId);
		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet createSheet = workbook.createSheet("Student Details");
		//XSSFRow createRow = createSheet.createRow(0);
		int dataRowIndex = 1;
		XSSFRow dataRow = createSheet.createRow(dataRowIndex);
		dataRow = createSheet.createRow(dataRowIndex);
		dataRow.createCell(2).setCellValue("Subject Name");
		dataRow.createCell(3).setCellValue("Obtained Marks");
		dataRow.createCell(4).setCellValue("Passing Marks");
		dataRow.createCell(5).setCellValue("Total Marks");
		dataRowIndex++;
		for(ReportCard rc:reportCards) {
			dataRow = createSheet.createRow(dataRowIndex);
			dataRow.createCell(2).setCellValue(rc.getSubjectName());
			dataRow.createCell(3).setCellValue(rc.getMarksObtained());
			dataRow.createCell(4).setCellValue(rc.getMinMarks());
			dataRow.createCell(5).setCellValue(rc.getMaxMarks());
			dataRowIndex++;
		}
		ServletOutputStream outputStream = response.getOutputStream();
		workbook.write(outputStream);
		workbook.close();
		outputStream.close();

	}
	
	
	@Override
	public void generateXSSFTable(HttpServletResponse response, Long StudentId) throws IOException{
		List<ReportCard> reportCards = studentRepository.getReportCard(StudentId);
		Workbook wb = new XSSFWorkbook();
	    XSSFSheet sheet = (XSSFSheet) wb.createSheet();
	    AreaReference reference = wb.getCreationHelper().createAreaReference(
	                  new CellReference(6, 4), new CellReference(12, 8));
	    // Create
	    XSSFTable table = sheet.createTable(reference); //creates a table having 3 columns as of area reference
	    // but all of those have id 1, so we need repairing
	    table.getCTTable().getTableColumns().getTableColumnArray(1).setId(2);
	    table.getCTTable().getTableColumns().getTableColumnArray(2).setId(3);

	            table.setName("Test");
	            table.setDisplayName("Marks_Table");

	            // For now, create the initial style in a low-level way
	            table.getCTTable().addNewTableStyleInfo();
	            table.getCTTable().getTableStyleInfo().setName("TableStyleMedium2");
		// Style the table
        XSSFTableStyleInfo style = (XSSFTableStyleInfo) table.getStyle();
        style.setName("TableStyleMedium2");
        style.setShowColumnStripes(false);
        style.setShowRowStripes(true);
        style.setFirstColumn(false);
        style.setLastColumn(false);
        style.setShowRowStripes(true);
        style.setShowColumnStripes(true);
     // Set the values for the table
        XSSFRow row;
        XSSFCell cell;
        row = sheet.createRow(6);
        cell = row.createCell(4);
        cell.setCellValue("Serial Number");
        cell = row.createCell(5);
        cell.setCellValue("Subject Name");
        cell =row.createCell(6);
        cell.setCellValue("Obtained Marks");
        cell =row.createCell(7);
        cell.setCellValue("Minimum Marks");
        cell =row.createCell(8);
        cell.setCellValue("Maximum Marks");
        int i=7;
    		for(ReportCard rc:reportCards) {
    	        row = sheet.createRow(i);
    	        cell=row.createCell(4);cell.setCellValue(i-6);
    			cell=row.createCell(5);cell.setCellValue(rc.getSubjectName());
    			cell=row.createCell(6);cell.setCellValue(rc.getMarksObtained());
    			cell=row.createCell(7);cell.setCellValue(rc.getMinMarks());
    			cell=row.createCell(8);cell.setCellValue(rc.getMaxMarks());
    			i++;
    		}
    	ReportCard basicData = studentRepository.getBasicInfo(StudentId);
    	System.out.println(basicData);
//    	reference = wb.getCreationHelper().createAreaReference(new CellReference(1, 4), new CellReference(4, 5));
//    	table = sheet.createTable(reference);
//    	 table.setName("Test1");
//         table.setDisplayName("Details_Table");
    	CellStyle cellStyle1 = wb.createCellStyle();
    	cellStyle1.setAlignment(HorizontalAlignment.CENTER);
		cellStyle1.setBorderTop(BorderStyle.MEDIUM);
		cellStyle1.setBorderBottom(BorderStyle.MEDIUM);
		cellStyle1.setBorderLeft(BorderStyle.MEDIUM);
		cellStyle1.setBorderRight(BorderStyle.MEDIUM);
		
    	 row = sheet.createRow(1);
         cell = row.createCell(4);
         cell.setCellValue("Roll Number");
         cell.setCellStyle(cellStyle1);
         cell = row.createCell(5);
         cell.setCellValue(basicData.getRollNo());
         cell.setCellStyle(cellStyle1);
         row = sheet.createRow(2);
         cell = row.createCell(4);
         cell.setCellValue("University Name");
         cell.setCellStyle(cellStyle1);
         cell = row.createCell(5);
         cell.setCellValue(basicData.getUniversityName());
         cell.setCellStyle(cellStyle1);
    	 row = sheet.createRow(3);
         cell = row.createCell(4);
         cell.setCellValue("Degree Name");
         cell.setCellStyle(cellStyle1);
         cell = row.createCell(5);
         cell.setCellValue(basicData.getDegreeName());
         cell.setCellStyle(cellStyle1);
         row = sheet.createRow(4);
         cell = row.createCell(4);
         cell.setCellValue("Academic Year");
         cell.setCellStyle(cellStyle1);
         cell = row.createCell(5);
         cell.setCellValue(basicData.getAcedemicYear());
         cell.setCellStyle(cellStyle1);
    	
         row = sheet.createRow(14);
         cell = row.createCell(4);
         cell.setCellValue("Total");
         cell.setCellStyle(cellStyle1);
         cell = row.createCell(5);
         cell.setCellValue("Obtained:");
         cell.setCellStyle(cellStyle1);
         cell = row.createCell(6);
         cell.setCellValue(studentRepository.getTotalMarks(StudentId));
         cell.setCellStyle(cellStyle1);
         cell = row.createCell(7);
         cell.setCellValue("Out of:");
         cell.setCellStyle(cellStyle1);
         cell = row.createCell(8);
         cell.setCellValue(studentRepository.getOutOfMarks(StudentId));
         cell.setCellStyle(cellStyle1);

         row = sheet.createRow(15);
         cell = row.createCell(4);
         cell.setCellValue("Percent");
         cell.setCellStyle(cellStyle1);
         cell = row.createCell(5);
         cell.setCellFormula("G15/I15*100");
         cell.setCellStyle(cellStyle1);

         
 		sheet.autoSizeColumn(4);
 		sheet.autoSizeColumn(5);
 		sheet.autoSizeColumn(6);
 		sheet.autoSizeColumn(7);
 		sheet.autoSizeColumn(8);
			ServletOutputStream outputStream = response.getOutputStream();
			wb.write(outputStream);
			wb.close();
			outputStream.close();
	}
}
