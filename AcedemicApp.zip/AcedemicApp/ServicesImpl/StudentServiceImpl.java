package com.AcedemicApp.AcedemicApp.ServicesImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.AcedemicApp.AcedemicApp.Entity.Student;
import com.AcedemicApp.AcedemicApp.Repository.StudentRepository;
import com.AcedemicApp.AcedemicApp.Services.StudentService;
@Service
public class StudentServiceImpl implements StudentService {
	@Autowired
	private StudentRepository studentRepository;

	@Override
	public List<Student> getStudents() {
		// TODO Auto-generated method stub
		return studentRepository.findAll();
	}

	@Override
	public Student addStudent(Student student) {
		// TODO Auto-generated method stub
		studentRepository.save(student);
		return student;
	}

	@Override
	public Student updateStudent(Student student) {
		// TODO Auto-generated method stub
		studentRepository.save(student);
		return student;
	}

	@Override
	public Optional<Student> getStudent(Long studentID) {
		// TODO Auto-generated method stub
		return studentRepository.findById(studentID);
		}

	@SuppressWarnings("deprecation")
	@Override
	public void deleteStudent(Long studentID) {
		// TODO Auto-generated method stub
		studentRepository.getById(studentID);
		Student student = studentRepository.getOne(studentID);
		studentRepository.delete(student);
	}

	@Override
	public List<Object> getNameRollno(Long studentId) {
		// TODO Auto-generated method stub
		return studentRepository.getNameRollno(studentId);
	}
	
	@Override
	public List<List<Object>> getReport(Long studentId){
		return studentRepository.getReport(studentId);
	}
	
	@Override
	public int getTotalMarks(Long studentId) {
		return studentRepository.getTotalMarks(studentId);
	}

}
