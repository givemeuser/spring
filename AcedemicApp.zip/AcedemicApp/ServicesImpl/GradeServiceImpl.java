package com.AcedemicApp.AcedemicApp.ServicesImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.AcedemicApp.AcedemicApp.Entity.Grade;
import com.AcedemicApp.AcedemicApp.Repository.GradesRepository;
import com.AcedemicApp.AcedemicApp.Services.GradeService;
@Service
public class GradeServiceImpl implements GradeService {
	@Autowired
	private GradesRepository gradesRepository;

	@Override
	public List<Grade> getAllGrade() {
		// TODO Auto-generated method stub
		return gradesRepository.findAll();
	}

	@Override
	public Optional<Grade> getGrade(Long gradeId) {
		// TODO Auto-generated method stub
		return gradesRepository.findById(gradeId);
	}

	@Override
	public Grade addGrade(Grade grade) {
		// TODO Auto-generated method stub
		gradesRepository.save(grade);
		return grade;
	}

	@Override
	public Grade updateGrade(Grade grade) {
		// TODO Auto-generated method stub
		gradesRepository.save(grade);
		return grade;
	}

	@SuppressWarnings("deprecation")
	@Override
	public void deleteGrade(Long gradeId) {
		// TODO Auto-generated method stub
		gradesRepository.getById(gradeId);
		Grade grade = gradesRepository.getOne(gradeId);
		gradesRepository.delete(grade);
	}

}
