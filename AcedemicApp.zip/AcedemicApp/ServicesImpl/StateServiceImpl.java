package com.AcedemicApp.AcedemicApp.ServicesImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.AcedemicApp.AcedemicApp.Entity.State;
import com.AcedemicApp.AcedemicApp.Repository.StatesRepository;
import com.AcedemicApp.AcedemicApp.Services.StateService;
@Service
public class StateServiceImpl implements StateService{
	@Autowired
	private StatesRepository statesRepository;

	@Override
	public List<State> getAllState() {
		// TODO Auto-generated method stub
		return statesRepository.findAll();
	}

	@Override
	public Optional<State> getState(Long stateId) {
		// TODO Auto-generated method stub
		return statesRepository.findById(stateId);
	}

	@Override
	public State addState(State state) {
		// TODO Auto-generated method stub
		statesRepository.save(state);
		return state;
	}

	@Override
	public State updateState(State state) {
		// TODO Auto-generated method stub
		statesRepository.save(state);
		return state;
	}

	@SuppressWarnings("deprecation")
	@Override
	public void deleteState(Long stateId) {
		// TODO Auto-generated method stub
		statesRepository.getById(stateId);
		State state = statesRepository.getOne(stateId);
		statesRepository.delete(state);
	}

}
