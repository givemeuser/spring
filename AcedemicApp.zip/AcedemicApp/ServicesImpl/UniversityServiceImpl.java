package com.AcedemicApp.AcedemicApp.ServicesImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.AcedemicApp.AcedemicApp.Entity.University;
import com.AcedemicApp.AcedemicApp.Repository.UniversityRepository;
import com.AcedemicApp.AcedemicApp.Services.UniversityService;
@Service
public class UniversityServiceImpl implements UniversityService {
	@Autowired
	private UniversityRepository universityRepository;

	@Override
	public List<University> getAllUniversities() {
		// TODO Auto-generated method stub
		return universityRepository.findAll();
	}

	@Override
	public Optional<University> getUniversity(Long universityId) {
		// TODO Auto-generated method stub
		return universityRepository.findById(universityId);
	}

	@Override
	public University addUniversity(University university) {
		// TODO Auto-generated method stub
		universityRepository.save(university);
		return university;
	}

	@Override
	public University updateUniversity(University university) {
		// TODO Auto-generated method stub
		universityRepository.save(university);
		return university;
	}

	@SuppressWarnings("deprecation")
	@Override
	public void deleteUniversity(Long universityId) {
		// TODO Auto-generated method stub
		universityRepository.getById(universityId);
		University university = universityRepository.getOne(universityId);
		universityRepository.delete(university);
	}
}
