package com.AcedemicApp.AcedemicApp.ServicesImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.AcedemicApp.AcedemicApp.Entity.Subject;
import com.AcedemicApp.AcedemicApp.Repository.SubjectRepository;
import com.AcedemicApp.AcedemicApp.Services.SubjectService;

@Service
public class SubjectServiceImpl implements SubjectService {
	@Autowired
	private SubjectRepository subjectRepository;

	@Override
	public List<Subject> getAllSubjects() {
		// TODO Auto-generated method stub
		return subjectRepository.findAll();
	}

	@Override
	public Optional<Subject> getSubject(Long stateId) {
		// TODO Auto-generated method stub
		return subjectRepository.findById(stateId);
	}

	@Override
	public Subject addSubject(Subject subject) {
		// TODO Auto-generated method stub
		subjectRepository.save(subject);
		return subject;
	}

	@Override
	public Subject updateSubject(Subject subject) {
		// TODO Auto-generated method stub
		subjectRepository.save(subject);
		return subject;
	}

	@SuppressWarnings("deprecation")
	@Override
	public void deleteSubject(Long subjectId) {
		// TODO Auto-generated method stub
		subjectRepository.getById(subjectId);
		Subject subject = subjectRepository.getOne(subjectId);
		subjectRepository.delete(subject);
	}
}
