package com.AcedemicApp.AcedemicApp.ServicesImpl;


import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.util.Units;
import org.apache.poi.xwpf.usermodel.Document;
import org.apache.poi.xwpf.usermodel.ParagraphAlignment;
import org.apache.poi.xwpf.usermodel.TableRowAlign;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.AcedemicApp.AcedemicApp.Documentation.ReportCard;
import com.AcedemicApp.AcedemicApp.Repository.StudentRepository;
import com.AcedemicApp.AcedemicApp.Services.DocService;
@Service
public class DocServiceImpl implements DocService{
	@Autowired
	private StudentRepository studentRepository;
	static String logo = "D://logo.png";
	@Override
	public void generateWord(HttpServletResponse response, Long StudentID) throws IOException {
		// TODO Auto-generated method stub
		List<ReportCard> reportCards = studentRepository.getReportCard(StudentID);
		ReportCard studedentCard = studentRepository.getBasicInfo(StudentID);
		XWPFDocument doc = new XWPFDocument();
		XWPFParagraph p1 = doc.createParagraph();
		p1.setAlignment(ParagraphAlignment.CENTER);
		XWPFRun r1 = p1.createRun();
		
		try(FileInputStream fStream = new FileInputStream(logo)) {
			r1.addPicture(fStream,Document.PICTURE_TYPE_PNG, logo,Units.toEMU(349), Units.toEMU(64));
		} catch (InvalidFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        r1.addBreak();
        
		XWPFParagraph p2 = doc.createParagraph();
		p2.setAlignment(ParagraphAlignment.CENTER);
		XWPFRun r2 = p2.createRun();
        r2.setBold(true);
        r2.setItalic(true);
        r2.setFontSize(22);
        r2.setText("NSDL Database Management Limited (NDML)");
        r2.setFontFamily("Courier");
        r2.setColor("008000");
        r2.addBreak();
        
        XWPFParagraph p3 = doc.createParagraph();
        p3.setAlignment(ParagraphAlignment.CENTER);
        XWPFRun r3 = p3.createRun();
        XWPFTable table = doc.createTable();
        // Creating first Row
        XWPFTableRow row = table.getRow(0);
        row.getCell(0).setText("Student Roll No.");
        row.getCell(0).getParagraphs().get(0).getRuns().get(0).setBold(true);
        row.getCell(0).getParagraphs().get(0).getRuns().get(0).setColor("008000");
        row.getCell(0).getParagraphs().get(0).setAlignment(ParagraphAlignment.CENTER);
        row.addNewTableCell().setText("University Name");
        row.getCell(1).getParagraphs().get(0).getRuns().get(0).setBold(true);
        row.getCell(1).getParagraphs().get(0).getRuns().get(0).setColor("008000");
        row.getCell(1).getParagraphs().get(0).setAlignment(ParagraphAlignment.CENTER);
        row.addNewTableCell().setText("Degree Name");
        row.getCell(2).getParagraphs().get(0).getRuns().get(0).setBold(true);
        row.getCell(2).getParagraphs().get(0).getRuns().get(0).setColor("008000");
        row.getCell(2).getParagraphs().get(0).setAlignment(ParagraphAlignment.CENTER);
        row.addNewTableCell().setText("Academic Year");
        row.getCell(3).getParagraphs().get(0).getRuns().get(0).setBold(true);
        row.getCell(3).getParagraphs().get(0).getRuns().get(0).setColor("008000");
        row.getCell(3).getParagraphs().get(0).setAlignment(ParagraphAlignment.CENTER);

        XWPFTableRow row2 = table.createRow();
        row2.getCell(0).setText(""+studedentCard.getRollNo());
        row2.getCell(0).getParagraphs().get(0).setAlignment(ParagraphAlignment.CENTER);
        row2.getCell(1).setText(""+studedentCard.getUniversityName());
        row2.getCell(1).getParagraphs().get(0).setAlignment(ParagraphAlignment.CENTER);
        row2.getCell(2).setText(""+studedentCard.getDegreeName());
        row2.getCell(2).getParagraphs().get(0).setAlignment(ParagraphAlignment.CENTER);
        row2.getCell(3).setText(""+studedentCard.getAcedemicYear());
        row2.getCell(3).getParagraphs().get(0).setAlignment(ParagraphAlignment.CENTER);
        table.setWidth("100%");
        table.setTableAlignment(TableRowAlign.CENTER);
        r3.addBreak();
        
        XWPFParagraph p4 = doc.createParagraph();
        p4.setAlignment(ParagraphAlignment.CENTER);
        XWPFRun r4 = p4.createRun();
        
        XWPFTable table1 = doc.createTable();
        // Creating first Row
        XWPFTableRow row1 = table1.getRow(0);
        row1.getCell(0).setText("Subject Name");
        row1.getCell(0).getParagraphs().get(0).getRuns().get(0).setColor("0040ff");
        row1.getCell(0).getParagraphs().get(0).setAlignment(ParagraphAlignment.CENTER);
        row1.addNewTableCell().setText("Obtained Marks");
        row1.getCell(1).getParagraphs().get(0).getRuns().get(0).setColor("0040ff");
        row1.getCell(1).getParagraphs().get(0).setAlignment(ParagraphAlignment.CENTER);
        row1.addNewTableCell().setText("Minimum Marks");
        row1.getCell(2).getParagraphs().get(0).getRuns().get(0).setColor("ff0000");
        row1.getCell(2).getParagraphs().get(0).setAlignment(ParagraphAlignment.CENTER);
        row1.addNewTableCell().setText("Maximum Marks");
        row1.getCell(3).getParagraphs().get(0).getRuns().get(0).setColor("00ff55");
        row1.getCell(3).getParagraphs().get(0).setAlignment(ParagraphAlignment.CENTER);
        table1.setWidth("100%");
        table1.setTableAlignment(TableRowAlign.CENTER);
        
        for(ReportCard rc:reportCards) {
            XWPFTableRow row3 = table1.createRow();
            row3.getCell(0).setText(rc.getSubjectName());
            row3.getCell(0).getParagraphs().get(0).setAlignment(ParagraphAlignment.CENTER);
            row3.getCell(1).setText(""+rc.getMarksObtained());
            if(rc.getMarksObtained()<35) {
            row3.getCell(1).getParagraphs().get(0).getRuns().get(0).setColor("ff0000");}
            else {
            row3.getCell(1).getParagraphs().get(0).getRuns().get(0).setColor("00ff55");}
            row3.getCell(1).getParagraphs().get(0).setAlignment(ParagraphAlignment.CENTER);
            row3.getCell(2).setText(""+rc.getMinMarks());
            row3.getCell(2).getParagraphs().get(0).getRuns().get(0).setColor("ff0000");
            row3.getCell(2).getParagraphs().get(0).setAlignment(ParagraphAlignment.CENTER);
            row3.getCell(3).setText(""+rc.getMaxMarks());
            row3.getCell(3).getParagraphs().get(0).getRuns().get(0).setColor("00ff55");
            row3.getCell(3).getParagraphs().get(0).setAlignment(ParagraphAlignment.CENTER);

        }
        r4.addBreak();
        
        XWPFParagraph p5 = doc.createParagraph();
        p5.setAlignment(ParagraphAlignment.CENTER);
        XWPFRun r5 = p5.createRun();

        XWPFTable table2 = doc.createTable();
        // Creating first Row
        XWPFTableRow row4 = table2.getRow(0);
        int tMarks =studentRepository.getTotalMarks(StudentID);
        int otMarks =studentRepository.getOutOfMarks(StudentID);
        float percent=(float)tMarks/(float)otMarks*100;
        row4.getCell(0).setText("Total Obtained Marks");
        row4.getCell(0).getParagraphs().get(0).setAlignment(ParagraphAlignment.CENTER);
        row4.addNewTableCell().setText(""+tMarks);
        row4.getCell(1).getParagraphs().get(0).setAlignment(ParagraphAlignment.CENTER);
        row4.addNewTableCell().setText("Out of");
        row4.getCell(2).getParagraphs().get(0).setAlignment(ParagraphAlignment.CENTER);
        row4.addNewTableCell().setText(""+otMarks);
        row4.getCell(3).getParagraphs().get(0).setAlignment(ParagraphAlignment.CENTER);

        XWPFTableRow row5 = table2.createRow();
        row5.getCell(0).setText("Percentage");
        row5.getCell(0).getParagraphs().get(0).setAlignment(ParagraphAlignment.CENTER);
        row5.getCell(1).setText(""+percent);
        row5.getCell(1).getParagraphs().get(0).setAlignment(ParagraphAlignment.CENTER);
        row4.getCell(0).setWidth("39%");
        row4.getCell(1).setWidth("20.33%");
        row4.getCell(2).setWidth("20.33%");
        row4.getCell(3).setWidth("20.33%");
        table2.setWidth("100%");
        table2.setTableAlignment(TableRowAlign.CENTER);

        r5.addBreak();
        
		ServletOutputStream outputStream = response.getOutputStream();
		doc.write(outputStream);
		doc.close();
		outputStream.close();
	}
	
}
