package com.AcedemicApp.AcedemicApp.ServicesImpl;


import java.util.List;


import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.AcedemicApp.AcedemicApp.Documentation.ReportCard;
import com.AcedemicApp.AcedemicApp.Repository.StudentRepository;
import com.AcedemicApp.AcedemicApp.Services.pdfService;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
/*import com.lowagie.text.Document;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Image;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.CMYKColor;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;*/
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.CMYKColor;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;


@Service
public class pdfServiceImpl implements pdfService {
	@Autowired
	private StudentRepository studentRepository;
	static String logo = "D://logo.png";

	@Override
	public void generatePDF(HttpServletResponse response, Long StudentID) throws Exception {
		// TODO Auto-generated method stub
		List<ReportCard> reportCards = studentRepository.getReportCard(StudentID);
		ReportCard studedentCard = studentRepository.getBasicInfo(StudentID);
		
		 Document document = new Document(PageSize.A4);
		    // Getting instance of PdfWriter
		    PdfWriter.getInstance(document, response.getOutputStream());
		    // Opening the created document to change it
		    document.open();
		    // Creating font
		    // Setting font style and size
		    Font fontTiltle = FontFactory.getFont(FontFactory.HELVETICA);
		    fontTiltle.setSize(22);
		    fontTiltle.setColor(CMYKColor.RED);
		    
		    Paragraph paragraph = new Paragraph();
		    // Aligning the paragraph in the document
		    paragraph.setAlignment(Paragraph.ALIGN_CENTER);
		    // Adding the created paragraph in the document
		    document.add(paragraph);
		    Image img= Image.getInstance(logo);
		    document.add(img);
		    
		    // Creating paragraph
		    Paragraph paragraph1 = new Paragraph("NSDL Database Management Limited (NDML)", fontTiltle);
		    // Aligning the paragraph in the document
		    paragraph1.setAlignment(Paragraph.ALIGN_CENTER);
		    // Adding the created paragraph in the document
		    document.add(paragraph1);
		    // Creating a table of the 4 columns
		    PdfPTable table = new PdfPTable(4);
		    // Setting width of the table, its columns and spacing
		    table.setWidthPercentage(100f);
		    table.setWidths(new int[] {3,3,3,3});
		    table.setSpacingBefore(10);
		    table.setHorizontalAlignment(Element.ALIGN_CENTER);
		    // Create Table Cells for the table header
		    PdfPCell cell = new PdfPCell();
		    // Setting the background color and padding of the table cell
		    cell.setBackgroundColor(CMYKColor.BLUE);
		    cell.setPadding(5);
		    cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		    // Creating font
		    // Setting font style and size
		    Font font = FontFactory.getFont(FontFactory.TIMES_ROMAN);
		    font.setColor(CMYKColor.MAGENTA);
		    // Adding headings in the created table cell or  header
		    // Adding Cell to table
		    cell.setPhrase(new Phrase("Roll No", font));
		    table.addCell(cell);
		    cell.setPhrase(new Phrase("Degree Name", font));
		    table.addCell(cell);
		    cell.setPhrase(new Phrase("University Name", font));
		    table.addCell(cell);
		    cell.setPhrase(new Phrase("Academic Year", font));
		    table.addCell(cell);
		      table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		      // Adding Roll No
		      table.addCell(String.valueOf(studedentCard.getRollNo()));
		      // Adding Degree Name
		      table.addCell(String.valueOf(studedentCard.getDegreeName()));
		      // Adding University Name
		      table.addCell(String.valueOf(studedentCard.getUniversityName()));
		      // Adding Academic Year
		      table.addCell(String.valueOf(studedentCard.getAcedemicYear()));
		    // Adding the created table to the document
		    document.add(table);
		    
		    Font fontTiltle1 = FontFactory.getFont(FontFactory.TIMES_ROMAN);
		    fontTiltle1.setSize(20);
		    
		    // Creating paragraph
		    Paragraph paragraph2 = new Paragraph("Report Card", fontTiltle1);
		    // Aligning the paragraph in the document
		    paragraph2.setAlignment(Paragraph.ALIGN_CENTER);
		    // Adding the created paragraph in the document
		    document.add(paragraph2);
		    // Creating a table of the 4 columns
		    PdfPTable table1 = new PdfPTable(4);
		    // Setting width of the table, its columns and spacing
		    table1.setWidthPercentage(100f);
		    table1.setWidths(new int[] {3,3,3,3});
		    table1.setSpacingBefore(10);
		    table1.setHorizontalAlignment(Element.ALIGN_CENTER);
		    // Create Table Cells for the table header
		    PdfPCell cell1 = new PdfPCell();
		    // Setting the background color and padding of the table cell
		    cell1.setBackgroundColor(CMYKColor.BLUE);
		    cell1.setPadding(5);
		    cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
		      table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		    // Creating font
		    // Setting font style and size
		    Font font1 = FontFactory.getFont(FontFactory.TIMES_ROMAN);
		    font1.setColor(CMYKColor.WHITE);
		    // Adding headings in the created table1 cell1
		    // Adding Cell1 to table1
		    cell1.setPhrase(new Phrase("Subject Name", font1));
		    table1.addCell(cell1);
		    cell1.setPhrase(new Phrase("Obtained Marks", font1));
		    table1.addCell(cell1);
		    cell1.setPhrase(new Phrase("Minimum Marks", font1));
		    table1.addCell(cell1);
		    cell1.setPhrase(new Phrase("Maximum Marks", font1));
		    table1.addCell(cell1);
		    // Iterating the list of student's reportCards
		    for (ReportCard report: reportCards) {
			  // Adding SubjectName
		      table1.addCell(String.valueOf(report.getSubjectName()));
		      // Adding MarksObtained
		      table1.addCell(String.valueOf(report.getMarksObtained()));
		      // Adding MinMarks
		      table1.addCell(String.valueOf(report.getMinMarks()));
		      // Adding MaxMarks
		      table1.addCell(String.valueOf(report.getMaxMarks()));
		    }
		    // Adding the created table1 to the document
		    document.add(table1);
		    
		    // Creating a table of the 4 columns
		    PdfPTable table2 = new PdfPTable(4);
		    // Setting width of the table, its columns and spacing
		    table2.setWidthPercentage(100f);
		    table2.setWidths(new int[] {3,3,3,3});
		    table2.setSpacingBefore(5);
		    table2.setHorizontalAlignment(Element.ALIGN_CENTER);
		    // Create Table Cells for the table header
		    PdfPCell cell2 = new PdfPCell();
		    // Setting the background color and padding of the table cell
		    cell2.setPadding(5);
		    cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
		    // Creating font
		    // Setting font style and size
		    Font font2 = FontFactory.getFont(FontFactory.TIMES_ROMAN);
		    font2.setColor(CMYKColor.MAGENTA);
		    // Adding headings in the created table cell or  header
		    // Adding Cell to table
		   
		    float tMarks = (float)studentRepository.getTotalMarks(StudentID);
		    float otMarks = (float)studentRepository.getOutOfMarks(StudentID);
		    
		    cell2.setPhrase(new Phrase("Total Obtained Marks", font2));
		    table2.addCell(cell2);
		    cell2.setPhrase(new Phrase(""+studentRepository.getTotalMarks(StudentID)));
		    table2.addCell(cell2);
		      table2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		      table2.addCell(new Phrase("Out Of", font2));
		      table2.addCell(String.valueOf(studentRepository.getOutOfMarks(StudentID)));
		      table2.addCell(new Phrase("Percentage", font2));
		      table2.addCell(""+tMarks/otMarks*100+"%");
		      cell2.setPhrase(new Phrase(""));
		      cell2.disableBorderSide(Rectangle.BOX);
		      table2.addCell(cell2);
		      table2.addCell(cell2);
		    document.add(table2);
		    
		    // Closing the document
			document.close();
		
	}
	
	@Override
	public void generateGradePDF(HttpServletResponse response, Long StudentID) throws Exception {
		// TODO Auto-generated method stub
		List<ReportCard> reportCards = studentRepository.getGradeCard(StudentID);
		ReportCard studedentCard = studentRepository.getBasicInfo(StudentID);
		
		 Document document = new Document(PageSize.A4);
		    // Getting instance of PdfWriter
		    PdfWriter.getInstance(document, response.getOutputStream());
		    // Opening the created document to change it
		    document.open();
		    // Creating font
		    // Setting font style and size
		    Font fontTiltle = FontFactory.getFont(FontFactory.HELVETICA);
		    fontTiltle.setSize(22);
		    fontTiltle.setColor(CMYKColor.RED);
		    
		    Paragraph paragraph = new Paragraph();
		    // Aligning the paragraph in the document
		    paragraph.setAlignment(Paragraph.ALIGN_CENTER);
		    // Adding the created paragraph in the document
		    document.add(paragraph);
		    Image img= Image.getInstance(logo);
		    document.add(img);
		    
		    // Creating paragraph
		    Paragraph paragraph1 = new Paragraph("NSDL Database Management Limited (NDML)", fontTiltle);
		    // Aligning the paragraph in the document
		    paragraph1.setAlignment(Paragraph.ALIGN_CENTER);
		    // Adding the created paragraph in the document
		    document.add(paragraph1);
		    // Creating a table of the 4 columns
		    PdfPTable table = new PdfPTable(4);
		    // Setting width of the table, its columns and spacing
		    table.setWidthPercentage(100f);
		    table.setWidths(new int[] {3,3,3,3});
		    table.setSpacingBefore(10);
		    table.setHorizontalAlignment(Element.ALIGN_CENTER);
		    // Create Table Cells for the table header
		    PdfPCell cell = new PdfPCell();
		    // Setting the background color and padding of the table cell
		    cell.setBackgroundColor(CMYKColor.BLUE);
		    cell.setPadding(5);
		    cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		    // Creating font
		    // Setting font style and size
		    Font font = FontFactory.getFont(FontFactory.TIMES_ROMAN);
		    font.setColor(CMYKColor.MAGENTA);
		    // Adding headings in the created table cell or  header
		    // Adding Cell to table
		    cell.setPhrase(new Phrase("Roll No", font));
		    table.addCell(cell);
		    cell.setPhrase(new Phrase("Degree Name", font));
		    table.addCell(cell);
		    cell.setPhrase(new Phrase("University Name", font));
		    table.addCell(cell);
		    cell.setPhrase(new Phrase("Academic Year", font));
		    table.addCell(cell);
		      table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		      // Adding Roll No
		      table.addCell(String.valueOf(studedentCard.getRollNo()));
		      // Adding Degree Name
		      table.addCell(String.valueOf(studedentCard.getDegreeName()));
		      // Adding University Name
		      table.addCell(String.valueOf(studedentCard.getUniversityName()));
		      // Adding Academic Year
		      table.addCell(String.valueOf(studedentCard.getAcedemicYear()));
		    // Adding the created table to the document
		    document.add(table);
		    
		    Font fontTiltle1 = FontFactory.getFont(FontFactory.TIMES_ROMAN);
		    fontTiltle1.setSize(20);
		    
		    // Creating paragraph
		    Paragraph paragraph2 = new Paragraph("Report Card", fontTiltle1);
		    // Aligning the paragraph in the document
		    paragraph2.setAlignment(Paragraph.ALIGN_CENTER);
		    // Adding the created paragraph in the document
		    document.add(paragraph2);
		    // Creating a table of the 5 columns
		    PdfPTable table1 = new PdfPTable(5);
		    // Setting width of the table, its columns and spacing
		    table1.setWidthPercentage(100f);
		    //table1.setWidths(new int[] {3,3,3,3,3});
		    table1.setSpacingBefore(10);
		    table1.setHorizontalAlignment(Element.ALIGN_CENTER);
		    // Create Table Cells for the table header
		    PdfPCell cell1 = new PdfPCell();
		    // Setting the background color and padding of the table cell
		    cell1.setBackgroundColor(CMYKColor.BLUE);
		    cell1.setPadding(5);
		    cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
		      table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		    // Creating font
		    // Setting font style and size
		    Font font1 = FontFactory.getFont(FontFactory.TIMES_ROMAN);
		    font1.setColor(CMYKColor.WHITE);
		    // Adding headings in the created table1 cell1
		    // Adding Cell1 to table1
		    cell1.setPhrase(new Phrase("Subject Name", font1));
		    table1.addCell(cell1);
		    cell1.setPhrase(new Phrase("Obtained Marks", font1));
		    table1.addCell(cell1);
		    cell1.setPhrase(new Phrase("Minimum Marks", font1));
		    table1.addCell(cell1);
		    cell1.setPhrase(new Phrase("Maximum Marks", font1));
		    table1.addCell(cell1);
		    cell1.setPhrase(new Phrase("Grade", font1));
		    table1.addCell(cell1);
		    // Iterating the list of student's reportCards
		    for (ReportCard report: reportCards) {
			  // Adding SubjectName
		      table1.addCell(String.valueOf(report.getSubjectName()));
		      // Adding MarksObtained
		      table1.addCell(String.valueOf(report.getMarksObtained()));
		      // Adding MinMarks
		      table1.addCell(String.valueOf(report.getMinMarks()));
		      // Adding MaxMarks
		      table1.addCell(String.valueOf(report.getMaxMarks()));
		      // Adding Grade
		      table1.addCell(String.valueOf(report.getGradeName()));

		    }
		    // Adding the created table1 to the document
		    document.add(table1);
		    
		    // Creating a table of the 4 columns
		    PdfPTable table2 = new PdfPTable(4);
		    // Setting width of the table, its columns and spacing
		    table2.setWidthPercentage(100f);
		    table2.setWidths(new int[] {3,3,3,3});
		    table2.setSpacingBefore(5);
		    table2.setHorizontalAlignment(Element.ALIGN_CENTER);
		    // Create Table Cells for the table header
		    PdfPCell cell2 = new PdfPCell();
		    // Setting the background color and padding of the table cell
		    cell2.setPadding(5);
		    cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
		    // Creating font
		    // Setting font style and size
		    Font font2 = FontFactory.getFont(FontFactory.TIMES_ROMAN);
		    font2.setColor(CMYKColor.MAGENTA);
		    // Adding headings in the created table cell or  header
		    // Adding Cell to table
		   
		    float tMarks = (float)studentRepository.getTotalMarks(StudentID);
		    float otMarks = (float)studentRepository.getOutOfMarks(StudentID);
		    
		    cell2.setPhrase(new Phrase("Total Obtained Marks", font2));
		    table2.addCell(cell2);
		    cell2.setPhrase(new Phrase(""+studentRepository.getTotalMarks(StudentID)));
		    table2.addCell(cell2);
		      table2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		      table2.addCell(new Phrase("Out Of", font2));
		      table2.addCell(String.valueOf(studentRepository.getOutOfMarks(StudentID)));
		      table2.addCell(new Phrase("Percentage", font2));
		      table2.addCell(""+tMarks/otMarks*100+"%");
		      cell2.setPhrase(new Phrase(""));
		      cell2.disableBorderSide(Rectangle.BOX);
		      table2.addCell(cell2);
		      table2.addCell(cell2);
		    document.add(table2);
		    
		    // Closing the document
			document.close();
		
	}
}
