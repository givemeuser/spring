package com.AcedemicApp.AcedemicApp.Services;

import java.util.List;
import java.util.Optional;

import com.AcedemicApp.AcedemicApp.Entity.Marks;

public interface MarksService {

	List<Marks> getAllMarks();

	Optional<Marks> getMarks(Long marksId);

	Marks addMarks(Marks marks);

	Marks updateMarks(Marks marks);

	void deleteMarks(Long marksId);

}
