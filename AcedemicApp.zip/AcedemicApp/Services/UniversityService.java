package com.AcedemicApp.AcedemicApp.Services;

import java.util.List;
import java.util.Optional;

import com.AcedemicApp.AcedemicApp.Entity.University;

public interface UniversityService {

	List<University> getAllUniversities();

	Optional<University> getUniversity(Long universityId);

	University addUniversity(University university);

	University updateUniversity(University university);

	void deleteUniversity(Long universityId);

}
