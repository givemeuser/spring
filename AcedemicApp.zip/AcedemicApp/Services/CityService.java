package com.AcedemicApp.AcedemicApp.Services;

import java.util.List;
import java.util.Optional;

import com.AcedemicApp.AcedemicApp.Entity.City;

public interface CityService {

	List<City> getCities();

	Optional<City> getCity(Long cityId);

	City addCity(City city);

	City updateCity(City city);

	void deleteCity(Long cityId);

}
