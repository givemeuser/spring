package com.AcedemicApp.AcedemicApp.Services;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

public interface DocService {

	void generateWord(HttpServletResponse response, Long studentID) throws IOException;

	void generateGradeWord(HttpServletResponse response, Long StudentID) throws IOException;
	
}
