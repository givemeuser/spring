package com.AcedemicApp.AcedemicApp.Services;

import java.util.List;
import java.util.Optional;

import com.AcedemicApp.AcedemicApp.Entity.Subject;

public interface SubjectService {

	List<Subject> getAllSubjects();

	Optional<Subject> getSubject(Long stateId);

	Subject addSubject(Subject state);

	Subject updateSubject(Subject state);

	void deleteSubject(Long subjectId);

}
