package com.AcedemicApp.AcedemicApp.Services;

import java.util.List;
import java.util.Optional;

import com.AcedemicApp.AcedemicApp.Entity.Grade;

public interface GradeService {

	List<Grade> getAllGrade();

	Optional<Grade> getGrade(Long gradeId);

	Grade addGrade(Grade grade);

	Grade updateGrade(Grade grades);

	void deleteGrade(Long gradeId);
}
