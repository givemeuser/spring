package com.AcedemicApp.AcedemicApp.Services;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

public interface ExcelService {

	void generatedXls(HttpServletResponse response) throws IOException;

	void generatedRep(HttpServletResponse response, Long StudentId) throws IOException;
	
	void generateDTOxlsx(HttpServletResponse response, Long StudentId) throws IOException;

	void generateXSSFTable(HttpServletResponse response, Long StudentId) throws IOException;
	
}
