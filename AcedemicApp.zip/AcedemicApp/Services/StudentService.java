package com.AcedemicApp.AcedemicApp.Services;

import java.util.List;
import java.util.Optional;

import com.AcedemicApp.AcedemicApp.Entity.Student;

public interface StudentService {

	List<Student> getStudents();

	Optional<Student> getStudent(Long studentID);

	Student addStudent(Student student);

	Student updateStudent(Student student);

	void deleteStudent(Long studentID);

	List<Object> getNameRollno(Long studentId);
	
	List<List<Object>> getReport(Long studentId);
	
}
