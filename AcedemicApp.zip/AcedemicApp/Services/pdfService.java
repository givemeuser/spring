package com.AcedemicApp.AcedemicApp.Services;

import javax.servlet.http.HttpServletResponse;

public interface pdfService {

	void generatePDF(HttpServletResponse response, Long studentID) throws Exception;

	void generateGradePDF(HttpServletResponse response, Long StudentID) throws Exception;

}
