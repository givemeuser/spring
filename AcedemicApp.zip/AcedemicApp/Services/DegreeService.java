package com.AcedemicApp.AcedemicApp.Services;

import java.util.List;
import java.util.Optional;

import com.AcedemicApp.AcedemicApp.Entity.Degree;

public interface DegreeService {

	List<Degree> getAllDegree();

	Optional<Degree> getDegree(Long degreeId);

	Degree addDegree(Degree degree);

	Degree updateDegree(Degree degree);

	void deleteDegree(Long degreeId);

}
