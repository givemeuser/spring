package com.AcedemicApp.AcedemicApp.Services;

import java.util.List;
import java.util.Optional;

import com.AcedemicApp.AcedemicApp.Entity.Country;

public interface CountryService {
	
	List<Country> getCountries();

	Optional<Country> getCountry(Long countryId);

	Country addCountry(Country country);

	Country updateCountry(Country country);

	void deleteCountry(Long countryId);

}
