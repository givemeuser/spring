package com.AcedemicApp.AcedemicApp.Services;

import java.util.List;
import java.util.Optional;

import com.AcedemicApp.AcedemicApp.Entity.State;

public interface StateService {

	List<State> getAllState();

	Optional<State> getState(Long stateId);

	State addState(State state);

	State updateState(State state);

	void deleteState(Long stateId);
}
