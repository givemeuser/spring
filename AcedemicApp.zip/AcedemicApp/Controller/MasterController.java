package com.AcedemicApp.AcedemicApp.Controller;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.AcedemicApp.AcedemicApp.Entity.City;
import com.AcedemicApp.AcedemicApp.Entity.Country;
import com.AcedemicApp.AcedemicApp.Entity.Degree;
import com.AcedemicApp.AcedemicApp.Entity.Grade;
import com.AcedemicApp.AcedemicApp.Entity.Marks;
import com.AcedemicApp.AcedemicApp.Entity.State;
import com.AcedemicApp.AcedemicApp.Entity.Student;
import com.AcedemicApp.AcedemicApp.Entity.Subject;
import com.AcedemicApp.AcedemicApp.Entity.University;
import com.AcedemicApp.AcedemicApp.Services.CityService;
import com.AcedemicApp.AcedemicApp.Services.CountryService;
import com.AcedemicApp.AcedemicApp.Services.DegreeService;
import com.AcedemicApp.AcedemicApp.Services.ExcelService;
import com.AcedemicApp.AcedemicApp.Services.GradeService;
import com.AcedemicApp.AcedemicApp.Services.MarksService;
import com.AcedemicApp.AcedemicApp.Services.StateService;
import com.AcedemicApp.AcedemicApp.Services.StudentService;
import com.AcedemicApp.AcedemicApp.Services.SubjectService;
import com.AcedemicApp.AcedemicApp.Services.UniversityService;

@RestController
public class MasterController {
	@Autowired
	private CityService cityService;
	@Autowired
	private CountryService countryService;
	@Autowired
	private DegreeService degreeService;
	@Autowired
	private GradeService gradeService;
	@Autowired
	private MarksService marksService;
	@Autowired
	private StateService stateService;
	@Autowired
	private StudentService studentService;
	@Autowired
	private SubjectService subjectService;
	@Autowired
	private UniversityService universityService;
	@Autowired
	private ExcelService excelService;
	
	@GetMapping("/home")
	public String home() {
		return "Homepage";
	}
	
	/////////////////////////////////////////////////////////////student
	
	@GetMapping("/home/students")
	public List<Student> getStudents(){
		return this.studentService.getStudents();
	}
	
	@GetMapping("/home/students/{StudentID}")
	public Optional<Student> getStudent(@PathVariable Long StudentID) {
		return this.studentService.getStudent(StudentID);
	}
	
	@PostMapping("/home/students")
	public Student addStudent(@RequestBody Student student) {
		return this.studentService.addStudent(student);
	}
	
	@PutMapping("/home/students")
	public Student updateStudent(@RequestBody Student student) {
		return this.studentService.updateStudent(student);
	}
	
	@DeleteMapping("/home/students/{StudentID}")
	public ResponseEntity<HttpStatus> deleteStudent(@PathVariable Long StudentID){
		try{
			studentService.deleteStudent(StudentID);
			return new ResponseEntity<>(HttpStatus.OK);
		}catch (Exception e) {
			// TODO: handle exception
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	 
	@GetMapping("/home/students/basic/{StudentID}")
	public List<Object> getNameRollno(@PathVariable Long StudentID){
		System.out.println(studentService.getNameRollno(StudentID));
		return studentService.getNameRollno(StudentID);
	}
	
	@GetMapping("/home/students/report/{StudentID}")
	public List<List<Object>> getReport(@PathVariable Long StudentID){
		return studentService.getReport(StudentID);
	}
	//////////////////////////////////////////////////////city
	
	@GetMapping("/home/cities")
	public List<City> getCities(){
		return this.cityService.getCities();
	}
	
	@GetMapping("/home/cities/{cityId}")
	public Optional<City> getCity(@PathVariable Long cityId) {
		return this.cityService.getCity(cityId);
	}
	
	@PostMapping("/home/cities")
	public City addCity(@RequestBody City city) {
		return this.cityService.addCity(city);
	}
	
	@PutMapping("/home/cities")
	public City updateCity(@RequestBody City city) {
		return this.cityService.updateCity(city);
	}
	
	@DeleteMapping("/home/cities/{cityId}")
	public ResponseEntity<HttpStatus> deleteCity(@PathVariable Long cityId){
		try{
			cityService.deleteCity(cityId);
			return new ResponseEntity<>(HttpStatus.OK);
		}catch (Exception e) {
			// TODO: handle exception
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	////////////////////////////////////////////////////////////country
	@GetMapping("/home/country")
	public List<Country> getCountry(){
		return this.countryService.getCountries();
	}
	
	@GetMapping("/home/country/{countryId}")
	public Optional<Country> getCountry(@PathVariable Long countryId) {
		return this.countryService.getCountry(countryId);
	}
	
	@PostMapping("/home/country")
	public Country addCity(@RequestBody Country country) {
		return this.countryService.addCountry(country);
	}
	
	@PutMapping("/home/country")
	public Country updateCity(@RequestBody Country country) {
		return this.countryService.updateCountry(country);
	}
	
	@DeleteMapping("/home/country/{countryId}")
	public ResponseEntity<HttpStatus> deleteCountry(@PathVariable Long countryId){
		try{
			countryService.deleteCountry(countryId);
			return new ResponseEntity<>(HttpStatus.OK);
		}catch (Exception e) {
			// TODO: handle exception
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	//////////////////////////////////////////////////////////degree
	@GetMapping("/home/degree")
	public List<Degree> getAllDegree(){
		return this.degreeService.getAllDegree();
	}
	
	@GetMapping("/home/degree/{degreeId}")
	public Optional<Degree> getDegree(@PathVariable Long degreeId) {
		return this.degreeService.getDegree(degreeId);
	}
	
	@PostMapping("/home/degree")
	public Degree addDegree(@RequestBody Degree degree) {
		return this.degreeService.addDegree(degree);
	}
	
	@PutMapping("/home/degree")
	public Degree updateDegree(@RequestBody Degree degree) {
		return this.degreeService.updateDegree(degree);
	}
	
	@DeleteMapping("/home/degree/{degreeId}")
	public ResponseEntity<HttpStatus> deleteDegree(@PathVariable Long degreeId){
		try{
			degreeService.deleteDegree(degreeId);
			return new ResponseEntity<>(HttpStatus.OK);
		}catch (Exception e) {
			// TODO: handle exception
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	//////////////////////////////////////////////////////////////Grades
	@GetMapping("/home/grades")
	public List<Grade> getAllGrade(){
		return this.gradeService.getAllGrade();
	}
	
	@GetMapping("/home/grades/{gradeId}")
	public Optional<Grade> getGrade(@PathVariable Long gradeId) {
		return this.gradeService.getGrade(gradeId);
	}
	
	@PostMapping("/home/grades")
	public Grade addGrade(@RequestBody Grade grade) {
		return this.gradeService.addGrade(grade);
	}
	
	@PutMapping("/home/grades")
	public Grade updateGrade(@RequestBody Grade grades) {
		return this.gradeService.updateGrade(grades);
	}
	
	@DeleteMapping("/home/grades/{gradeId}")
	public ResponseEntity<HttpStatus> deleteGrade(@PathVariable Long gradeId){
		try{
			gradeService.deleteGrade(gradeId);
			return new ResponseEntity<>(HttpStatus.OK);
		}catch (Exception e) {
			// TODO: handle exception
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	//////////////////////////////////////////////////////////////marks
	@GetMapping("/home/marks")
	public List<Marks> getAllMarks(){
		return this.marksService.getAllMarks();
	}
	
	@GetMapping("/home/marks/{marksId}")
	public Optional<Marks> getMarks(@PathVariable Long marksId) {
		return this.marksService.getMarks(marksId);
	}
	
	@PostMapping("/home/marks")
	public Marks addMarks(@RequestBody Marks marks) {
		return this.marksService.addMarks(marks);
	}
	
	@PutMapping("/home/marks")
	public Marks updateMarks(@RequestBody Marks marks) {
		return this.marksService.updateMarks(marks);
	}
	
	@DeleteMapping("/home/marks/{marksId}")
	public ResponseEntity<HttpStatus> deleteMarks(@PathVariable Long marksId){
		try{
			marksService.deleteMarks(marksId);
			return new ResponseEntity<>(HttpStatus.OK);
		}catch (Exception e) {
			// TODO: handle exception
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	//////////////////////////////////////////////////////////////state
	@GetMapping("/home/states")
	public List<State> getAllState(){
		return this.stateService.getAllState();
	}
	
	@GetMapping("/home/states/{stateId}")
	public Optional<State> getState(@PathVariable Long stateId) {
		return this.stateService.getState(stateId);
	}
	
	@PostMapping("/home/states")
	public State addState(@RequestBody State state) {
		return this.stateService.addState(state);
	}
	
	@PutMapping("/home/states")
	public State updateState(@RequestBody State state) {
		return this.stateService.updateState(state);
	}
	
	@DeleteMapping("/home/states/{stateId}")
	public ResponseEntity<HttpStatus> deleteState(@PathVariable Long stateId){
		try{
			stateService.deleteState(stateId);
			return new ResponseEntity<>(HttpStatus.OK);
		}catch (Exception e) {
			// TODO: handle exception
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	//////////////////////////////////////////////////////////////subjects
	@GetMapping("/home/subjects")
	public List<Subject> getAllSubjects(){
		return this.subjectService.getAllSubjects();
	}
	
	@GetMapping("/home/subjects/{stateId}")
	public Optional<Subject> getSubject(@PathVariable Long stateId) {
		return this.subjectService.getSubject(stateId);
	}
	
	@PostMapping("/home/subjects")
	public Subject addSubject(@RequestBody Subject subject) {
		return this.subjectService.addSubject(subject);
	}
	
	@PutMapping("/home/subjects")
	public Subject updateSubject(@RequestBody Subject subject) {
		return this.subjectService.updateSubject(subject);
	}
	
	@DeleteMapping("/home/subjects/{subjectId}")
	public ResponseEntity<HttpStatus> deleteSubject(@PathVariable Long subjectId){
		try{
			subjectService.deleteSubject(subjectId);
			return new ResponseEntity<>(HttpStatus.OK);
		}catch (Exception e) {
			// TODO: handle exception
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	//////////////////////////////////////////////////////////////University
	@GetMapping("/home/university")
	public List<University> getAllUniversities(){
		return this.universityService.getAllUniversities();
	}
	
	@GetMapping("/home/university/{universityId}")
	public Optional<University> getUniversity(@PathVariable Long universityId) {
		return this.universityService.getUniversity(universityId);
	}
	
	@PostMapping("/home/university")
	public University addSubject(@RequestBody University university) {
		return this.universityService.addUniversity(university);
	}
	
	@PutMapping("/home/university")
	public University updateSubject(@RequestBody University university) {
		return this.universityService.updateUniversity(university);
	}
	
	@DeleteMapping("/home/university/{universityId}")
	public ResponseEntity<HttpStatus> deleteUniversity(@PathVariable Long universityId){
		try{
			universityService.deleteUniversity(universityId);
			return new ResponseEntity<>(HttpStatus.OK);
		}catch (Exception e) {
			// TODO: handle exception
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	//////////////////////////////////////////////////////////////Xls
	@GetMapping("/home/generateXls")
	public void generatedXls(HttpServletResponse response) {
		response.setContentType("application/octet-stream");
		String headerKey = "Content-Disposition";
		String headerValue = "attachment;filename=Students.xlsx";
		response.setHeader(headerKey, headerValue);
		try {
			this.excelService.generatedXls(response);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@GetMapping("/home/generateXls/{StudentID}")
	public void generatedRep(HttpServletResponse response,@PathVariable Long StudentID) {
		response.setContentType("application/octet-stream");
		String headerKey = "Content-Disposition";
		String headerValue = "attachment;filename=Students.xlsx";
		response.setHeader(headerKey, headerValue);
		try {
			this.excelService.generatedRep(response,StudentID);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
