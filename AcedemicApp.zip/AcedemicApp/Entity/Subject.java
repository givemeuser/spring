package com.AcedemicApp.AcedemicApp.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "subject_master")
public class Subject {
	@Id
	@Column(name = "subject_id")
	private Long subjectId;
	
	@Column(name = "year")
	private int year;
	
	@Column(name = "degree_id")
	private Long degreeId;
	
	@Column(name = "min_marks")
	private int minMarks;
	
	@Column(name = "total_marks")
	private int totalMarks;
	
	@Column(name = "created_by")
	private String createdBy;
	
	@Column(name = "updated_by")
	private String updatedBy;
	
	@Column(name= " subject_name")
	private String subjectName;

	public Subject(Long subjectId, int year, Long degreeId, int minMarks, int totalMarks, String createdBy,
			String updatedBy, String subjectName) {
		super();
		this.subjectId = subjectId;
		this.year = year;
		this.degreeId = degreeId;
		this.minMarks = minMarks;
		this.totalMarks = totalMarks;
		this.createdBy = createdBy;
		this.updatedBy = updatedBy;
		this.subjectName=subjectName;
	}

	public String getSubjectName() {
		return subjectName;
	}

	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}

	public Subject() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Long getSubjectId() {
		return subjectId;
	}

	public void setSubjectId(Long subjectId) {
		this.subjectId = subjectId;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public Long getDegreeId() {
		return degreeId;
	}

	public void setDegreeId(Long degreeId) {
		this.degreeId = degreeId;
	}

	public int getMinMarks() {
		return minMarks;
	}

	public void setMinMarks(int minMarks) {
		this.minMarks = minMarks;
	}

	public int getTotalMarks() {
		return totalMarks;
	}

	public void setTotalMarks(int totalMarks) {
		this.totalMarks = totalMarks;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	
}
