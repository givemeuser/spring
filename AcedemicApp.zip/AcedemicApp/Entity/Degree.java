package com.AcedemicApp.AcedemicApp.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "degree_master")
public class Degree {
	@Id
	@Column(name = "degree_id")
	private Long degreeId;
	
	@Column(name = "acedemic_year")
	private int acedemicYear;
	
	@Column(name = "degree_name")
	private String degreeName;
	
	@Column(name = "university_id")
	private Long universirtyId;
	
	@Column(name = "updated_on_date")
	private Long updatedOnDate;

	@Column(name = "updated_by")
	private Long updatedBy;

	public Degree(Long degreeId, int acedemicYear, String degreeName, Long universirtyId, Long updatedOnDate,
			Long updatedBy) {
		super();
		this.degreeId = degreeId;
		this.acedemicYear = acedemicYear;
		this.degreeName = degreeName;
		this.universirtyId = universirtyId;
		this.updatedOnDate = updatedOnDate;
		this.updatedBy = updatedBy;
	}

	public Degree() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Long getDegreeId() {
		return degreeId;
	}

	public void setDegreeId(Long degreeId) {
		this.degreeId = degreeId;
	}

	public int getAcedemicYear() {
		return acedemicYear;
	}

	public void setAcedemicYear(int acedemicYear) {
		this.acedemicYear = acedemicYear;
	}

	public String getDegreeName() {
		return degreeName;
	}

	public void setDegreeName(String degreeName) {
		this.degreeName = degreeName;
	}

	public Long getUniversirtyId() {
		return universirtyId;
	}

	public void setUniversirtyId(Long universirtyId) {
		this.universirtyId = universirtyId;
	}

	public Long getUpdatedOnDate() {
		return updatedOnDate;
	}

	public void setUpdatedOnDate(Long updatedOnDate) {
		this.updatedOnDate = updatedOnDate;
	}

	public Long getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(Long updatedBy) {
		this.updatedBy = updatedBy;
	}
	
}
