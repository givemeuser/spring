package com.AcedemicApp.AcedemicApp.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "university_master")
public class University {
	@Id
	@Column(name = "university_id")
	private Integer universityId;
	
	@Column(name = "university_name")
	private String universityName;

	public University(Integer universityId, String universityName) {
		super();
		this.universityId = universityId;
		this.universityName = universityName;
	}

	public University() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getUniversityId() {
		return universityId;
	}

	public void setUniversityId(Integer universityId) {
		this.universityId = universityId;
	}

	public String getUniversityName() {
		return universityName;
	}

	public void setUniversityName(String universityName) {
		this.universityName = universityName;
	}

}
