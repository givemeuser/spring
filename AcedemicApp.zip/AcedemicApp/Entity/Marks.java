package com.AcedemicApp.AcedemicApp.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "marks_master")
public class Marks {
	@Id
	@Column(name = "marks_id")
	private Long marksId;
	
	@Column(name = "marks_obtained")
	private int marksObtained;
	
	@Column(name = "degree_id")
	private Long degreeId;
	
	@Column(name = "student_id")
	private Long studentId;
	
	@Column(name = "subject_id")
	private Long subjectId;
	
	@Column(name = "university_id")
	private Long universityId;

	public Marks(Long marksId, int marksObtained, Long degreeId, Long studentId, Long subjectId, Long universityId) {
		super();
		this.marksId = marksId;
		this.marksObtained = marksObtained;
		this.degreeId = degreeId;
		this.studentId = studentId;
		this.subjectId = subjectId;
		this.universityId = universityId;
	}

	public Marks() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Long getMarksId() {
		return marksId;
	}

	public void setMarksId(Long marksId) {
		this.marksId = marksId;
	}

	public int getMarksObtained() {
		return marksObtained;
	}

	public void setMarksObtained(int marksObtained) {
		this.marksObtained = marksObtained;
	}

	public Long getDegreeId() {
		return degreeId;
	}

	public void setDegreeId(Long degreeId) {
		this.degreeId = degreeId;
	}

	public Long getStudentId() {
		return studentId;
	}

	public void setStudentId(Long studentId) {
		this.studentId = studentId;
	}

	public Long getSubjectId() {
		return subjectId;
	}

	public void setSubjectId(Long subjectId) {
		this.subjectId = subjectId;
	}

	public Long getUniversityId() {
		return universityId;
	}

	public void setUniversityId(Long universityId) {
		this.universityId = universityId;
	}

}
