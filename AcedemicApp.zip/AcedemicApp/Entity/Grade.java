package com.AcedemicApp.AcedemicApp.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "grade_master")
public class Grade {
	@Id
	@Column(name = "grade_id")
	private Long gradeId;
	
	@Column(name = "grade_name")
	private char gradeName;
	
	@Column(name = "range_from")
	private int rangeFrom;

	@Column(name = "range_to")
	private int rangeTo;
	
	@Column(name = "subject_id")
	private Long subjectId;

	@Column(name = "created_by")
	private Long createdBy;
	
	@Column(name = "updated_by")
	private Long updatedBy;

	public Grade(Long gradeId, char gradeName, int rangeFrom, int rangeTo, Long subjectId, Long createdBy,
			Long updatedBy) {
		super();
		this.gradeId = gradeId;
		this.gradeName = gradeName;
		this.rangeFrom = rangeFrom;
		this.rangeTo = rangeTo;
		this.subjectId = subjectId;
		this.createdBy = createdBy;
		this.updatedBy = updatedBy;
	}

	public Grade() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Long getGradeId() {
		return gradeId;
	}

	public void setGradeId(Long gradeId) {
		this.gradeId = gradeId;
	}

	public char getGradeName() {
		return gradeName;
	}

	public void setGradeName(char gradeName) {
		this.gradeName = gradeName;
	}

	public int getRangeFrom() {
		return rangeFrom;
	}

	public void setRangeFrom(int rangeFrom) {
		this.rangeFrom = rangeFrom;
	}

	public int getRangeTo() {
		return rangeTo;
	}

	public void setRangeTo(int rangeTo) {
		this.rangeTo = rangeTo;
	}

	public Long getSubjectId() {
		return subjectId;
	}

	public void setSubjectId(Long subjectId) {
		this.subjectId = subjectId;
	}

	public Long getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
	}

	public Long getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(Long updatedBy) {
		this.updatedBy = updatedBy;
	}
	
}
