package com.AcedemicApp.AcedemicApp.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity

@Table(name = "student_data")
public class Student {
	@Id
	@GeneratedValue
	@Column(name = "student_id")
	private Long studentId;
	
	@Column(name="name")
	private String name;
	
	@Column(name = "roll_no")
	private Long rollNo;
	
	@Column(name = "university_id")
	private Long universityId;
	
	@Column(name = "city_id")
	private Long cityId;
	
	@Column(name = "state_id")
	private Long stateId;

	@Column(name = "country_id")
	private Long countryId;
	
	@JsonIgnore
	@Column(name = "created_on_date")
	private Long createdOnDate;

	@JsonIgnore
	@Column(name = "created_by")
	private Long createdBy;
	
	@JsonIgnore
	@Column(name = "updated_on_date")
	private Long updatedOnDate;

	@JsonIgnore
	@Column(name = "updated_by")
	private Long updatedBy;

	public Student(Long studentId, String name, Long rollNo, Long universityId, Long cityId, Long stateId,
			Long countryId, Long createdOnDate, Long createdBy, Long updatedOnDate, Long updatedBy) {
		super();
		this.studentId = studentId;
		this.name = name;
		this.rollNo = rollNo;
		this.universityId = universityId;
		this.cityId = cityId;
		this.stateId = stateId;
		this.countryId = countryId;
		this.createdOnDate = createdOnDate;
		this.createdBy = createdBy;
		this.updatedOnDate = updatedOnDate;
		this.updatedBy = updatedBy;
	}

	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Long getStudentId() {
		return studentId;
	}

	public void setStudentId(Long studentId) {
		this.studentId = studentId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getRollNo() {
		return rollNo;
	}

	public void setRollNo(Long rollNo) {
		this.rollNo = rollNo;
	}

	public Long getUniversityId() {
		return universityId;
	}

	public void setUniversityId(Long universityId) {
		this.universityId = universityId;
	}

	public Long getCityId() {
		return cityId;
	}

	public void setCityId(Long cityId) {
		this.cityId = cityId;
	}

	public Long getStateId() {
		return stateId;
	}

	public void setStateId(Long stateId) {
		this.stateId = stateId;
	}

	public Long getCountryId() {
		return countryId;
	}

	public void setCountryId(Long countryId) {
		this.countryId = countryId;
	}

	public Long getCreatedOnDate() {
		return createdOnDate;
	}

	public void setCreatedOnDate(Long createdOnDate) {
		this.createdOnDate = createdOnDate;
	}

	public Long getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
	}

	public Long getUpdatedOnDate() {
		return updatedOnDate;
	}

	public void setUpdatedOnDate(Long updatedOnDate) {
		this.updatedOnDate = updatedOnDate;
	}

	public Long getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(Long updatedBy) {
		this.updatedBy = updatedBy;
	}

}
