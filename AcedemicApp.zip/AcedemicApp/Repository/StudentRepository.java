package com.AcedemicApp.AcedemicApp.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.AcedemicApp.AcedemicApp.Documentation.ReportCard;
import com.AcedemicApp.AcedemicApp.Entity.Student;
@Repository
public interface StudentRepository extends JpaRepository<Student, Long>{
	@Query(value = "select s.roll_no, s.name from student_data s where s.student_id =:studentId",nativeQuery = true)
	public List<Object> getNameRollno(@Param("studentId") long studentId);
	
	@Query(value="select sm.subject_name, mm.marks_obtained, sm.min_marks,sm.total_marks from marks_master mm inner join subject_master sm on sm.subject_id =mm.subject_id where mm.student_id=:studentId",nativeQuery = true)
	public List<List<Object>> getReport(@Param("studentId") long studentId);
	
	@Query(value="select sum(mm.marks_obtained) from marks_master mm inner join subject_master sm on sm.subject_id =mm.subject_id where mm.student_id =:studentId",nativeQuery = true)
	public int getTotalMarks(@Param("studentId") long studentId);
	
	@Query(value="select sum(sm.total_marks) from marks_master mm inner join subject_master sm on sm.subject_id =mm.subject_id where mm.student_id =:studentId",nativeQuery = true)
	public int getOutOfMarks(@Param("studentId") long studentId);
	
	@Query(value="select um.university_name from student_data sd left join university_master um on sd.university_id = um.university_id  where sd.student_id =:studentId",nativeQuery = true)
	public String getUniversityName(@Param("studentId") long studentId);
	
	@Query("select new com.AcedemicApp.AcedemicApp.Documentation.ReportCard(sm.subjectName as subjectName, mm.marksObtained as marksObtained, sm.minMarks as minMarks,sm.totalMarks as maxMarks) from Marks mm inner join Subject sm on sm.subjectId =mm.subjectId where mm.studentId=:studentId")
	public List<ReportCard> getReportCard(@Param("studentId") long studentId);
	
	@Query("select distinct new com.AcedemicApp.AcedemicApp.Documentation.ReportCard(sd.rollNo as rollNo, um.universityName as universityName, dm.degreeName as degreeName, dm.acedemicYear as acedemicYear) from Student sd inner join Marks mm on sd.studentId = mm.studentId inner join University um on um.universityId = mm.universityId inner join Degree dm on dm.degreeId = mm.degreeId where sd.studentId =:studentId")
	public ReportCard getBasicInfo(@Param("studentId") long studentId);
}
