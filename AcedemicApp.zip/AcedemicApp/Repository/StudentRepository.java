package com.AcedemicApp.AcedemicApp.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.AcedemicApp.AcedemicApp.Entity.Student;
@Repository
public interface StudentRepository extends JpaRepository<Student, Long>{
	@Query(value = "select s.roll_no, s.name from student_data s where s.student_id =:studentId",nativeQuery = true)
	public List<Object> getNameRollno(@Param("studentId") long studentId);
	
	@Query(value="select sm.subject_name, mm.marks_obtained, sm.min_marks,sm.total_marks from marks_master mm inner join subject_master sm on sm.subject_id =mm.subject_id where mm.student_id=:studentId",nativeQuery = true)
	public List<List<Object>> getReport(@Param("studentId") long studentId);
	
	
}
