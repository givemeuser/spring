package com.AcedemicApp.AcedemicApp.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.AcedemicApp.AcedemicApp.Entity.Student;
@Repository
public interface StudentRepository extends JpaRepository<Student, Long>{
	@Query(value = "select s.roll_no, s.name from student_data s where s.student_id =:studentId",nativeQuery = true)
	public List<Object> getNameRollno(@Param("studentId") long studentId);
	
}
