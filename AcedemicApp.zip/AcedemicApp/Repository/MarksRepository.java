package com.AcedemicApp.AcedemicApp.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.AcedemicApp.AcedemicApp.Entity.Marks;
@Repository
public interface MarksRepository extends JpaRepository<Marks, Long>{

}
