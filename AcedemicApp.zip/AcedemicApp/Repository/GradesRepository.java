package com.AcedemicApp.AcedemicApp.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.AcedemicApp.AcedemicApp.Entity.Grade;
@Repository
public interface GradesRepository extends JpaRepository<Grade, Long>{

}
