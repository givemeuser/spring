package com.AcedemicApp.AcedemicApp.Repository;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.AcedemicApp.AcedemicApp.Entity.Student;
/*
 

JPA specification
According to the JPA specification, an entity should implement Serializable only if it needs to be passed from one JVM to another or if the entity is used by a Stateful Session Bean which needs to be passivated by the EJB container.

If an entity instance is to be passed by value as a detached object (e.g., through a remote interface),
the entity class must implement the Serializable interface.
 * */
@Repository
public interface ExcelReposiory extends JpaRepository<Student, Serializable> {
	
}
