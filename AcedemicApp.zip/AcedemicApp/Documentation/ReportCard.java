package com.AcedemicApp.AcedemicApp.Documentation;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class ReportCard {
	Long rollNo;
	String studentName;
	String universityName;
	String degreeName;
	String subjectName;
	char gradeName;
	int marksObtained;
	int minMarks;
	int maxMarks;
	int acedemicYear;
	
	public int getAcedemicYear() {
		return acedemicYear;
	}

	public void setAcedemicYear(int acedemicYear) {
		this.acedemicYear = acedemicYear;
	}

	public ReportCard(String subjectName, int marksObtained, int minMarks, int maxMarks) {
		super();
		this.subjectName = subjectName;
		this.marksObtained = marksObtained;
		this.minMarks = minMarks;
		this.maxMarks = maxMarks;
	}
	
	public ReportCard(String subjectName, int marksObtained, int minMarks, int maxMarks, char gradeName) {
		super();
		this.subjectName = subjectName;
		this.marksObtained = marksObtained;
		this.minMarks = minMarks;
		this.maxMarks = maxMarks;
		this.gradeName = gradeName;
	}
	
	public ReportCard(Long rollNo, String universityName, String degreeName, int acedemicYear) {
		super();
		this.rollNo = rollNo;
		this.universityName = universityName;
		this.degreeName = degreeName;
		this.acedemicYear = acedemicYear;
	}

	public Long getRollNo() {
		return rollNo;
	}

	public void setRollNo(Long rollNo) {
		this.rollNo = rollNo;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getUniversityName() {
		return universityName;
	}

	public void setUniversityName(String universityName) {
		this.universityName = universityName;
	}

	public String getDegreeName() {
		return degreeName;
	}

	public void setDegreeName(String degreeName) {
		this.degreeName = degreeName;
	}

	public String getSubjectName() {
		return subjectName;
	}

	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}

	public int getMarksObtained() {
		return marksObtained;
	}

	public void setMarksObtained(int marksObtained) {
		this.marksObtained = marksObtained;
	}

	public int getMinMarks() {
		return minMarks;
	}

	public void setMinMarks(int minMarks) {
		this.minMarks = minMarks;
	}

	public int getMaxMarks() {
		return maxMarks;
	}

	public void setMaxMarks(int maxMarks) {
		this.maxMarks = maxMarks;
	}
	
	public char getGradeName() {
		return gradeName;
	}

	public void setGradeName(char gradeName) {
		this.gradeName = gradeName;
	}
	
}
