package com.AcedemicApp.AcedemicApp.Documentation;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.AcedemicApp.AcedemicApp.Repository.StudentRepository;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)

public class ReportCard {
	private String studentId;
	private String subjectName;
	private String marksObtained;
	private String minMark;
	private String maxMark;
	
	public ReportCard(String subjectName, String marksObtained, String minMark, String maxMark) {
		super();
		this.subjectName = subjectName;
		this.marksObtained = marksObtained;
		this.minMark = minMark;
		this.maxMark = maxMark;
	}

	public String getSubjectName() {
		return subjectName;
	}

	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}

	public String getMarksObtained() {
		return marksObtained;
	}

	public void setMarksObtained(String marksObtained) {
		this.marksObtained = marksObtained;
	}

	public String getMinMark() {
		return minMark;
	}

	public void setMinMark(String minMark) {
		this.minMark = minMark;
	}

	public String getMaxMark() {
		return maxMark;
	}

	public void setMaxMark(String maxMark) {
		this.maxMark = maxMark;
	}

	public String getStudentId() {
		return studentId;
	}

	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}
	
	@Autowired
	private StudentRepository studentRepository;
	
	public void setter(Long StudentId) {
		setStudentId(studentId);
		List<List<Object>> report=studentRepository.getReport(StudentId);
		for(int i=0;i<report.size();i++) {
			List<Object> innerList = report.get(i);
			setSubjectName(innerList.get(0).toString());
			setMarksObtained(innerList.get(1).toString());
			setMinMark(innerList.get(2).toString());
			setMarksObtained(innerList.get(3).toString());
		}
	}
	
}
