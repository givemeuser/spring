package com.AcedemicApp.AcedemicApp.Documentation;

public class XlGenerator {

}
